<?php

return [
    'title' => 'وبسایت پاپکو',

    'sweet-alert' => [
        'success' => 'عملیات با موفقیت انجام شد',
        'danger' => 'حذف با موفقیت انجام شد',
    ]
];
