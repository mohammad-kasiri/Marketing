// Libraries
require('./../assets/plugins/custom/prismjs/prismjs.bundle.js');
require('./../assets/js/jalaliDatepicker.min.js');

// My Scripts
require('./scripts/auth.otp');
require('./scripts/auth.timezone');

require('./scripts/user.patient.add');
require('./scripts/user.doctor.editor');



