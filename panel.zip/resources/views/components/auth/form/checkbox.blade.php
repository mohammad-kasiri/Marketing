<div class="checkbox-inline">
    <label class="checkbox m-0 text-muted">
        <input type="checkbox" name="{{$name}}" />
        <span></span>
        {{$slot}}
    </label>
</div>
