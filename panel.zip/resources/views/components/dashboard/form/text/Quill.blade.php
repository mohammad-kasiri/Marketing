@props(['name'])
<div id="QuilEditor" style="height: 325px" class="w-100">
    نوشتن پیام
</div>
<textarea name="{{ $name }}" style="display:none" id="QuilInput"></textarea>
