<!--begin::Toggle-->
<div class="topbar-item" data-toggle="dropdown" data-offset="10px,0px">
    <div class="btn btn-icon btn-clean btn-lg btn-dropdown mr-1">
        <span class="svg-icon svg-icon-xl svg-icon-primary">
            <x-dashboard.icons.svg.search/>
        </span>
    </div>
</div>
<!--end::Toggle-->
