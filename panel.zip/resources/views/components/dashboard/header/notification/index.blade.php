<div class="dropdown">
    <x-dashboard.header.notification.item  active="{{$active}}"/>
    <x-dashboard.header.notification.dropdown :notifications="$notifications"/>
</div>
