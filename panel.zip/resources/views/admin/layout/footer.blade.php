<div class="footer bg-white py-4 d-flex flex-lg-column mt-4" id="kt_footer">
    <!--begin::Container-->
    <div class=" container-fluid text-center">
        <p>سکوت موسیقی زیبایی نیست ؟</p>
    </div>
    <!--end::Container-->
</div>
