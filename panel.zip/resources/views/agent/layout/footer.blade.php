<div class="footer bg-white py-4 d-flex flex-lg-column mt-4" id="kt_footer">
    <!--begin::Container-->
    <div class=" container-fluid text-center">
        <p>کلینیک رامان</p>
    </div>
    <!--end::Container-->
</div>
